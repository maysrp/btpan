#mybloger

##权限
777
./Uploads
./Index/Runtime

##数据库
修改./Conf/config.php
中数据库及其密码
导入数据库:myblog.sql

##帐号
管理员：admin
默认密码: 1


#DEMO:
http://www.gjcomic.com

##微信绑定：
###微信工作平台
申请公众号：
https://mp.weixin.qq.com/
完成设置后进入到你申请的公众号之中，完成下面的步骤：

设置>
     公众号设置>
     用你自己的微信关注你的公众号！
开发>
	基本配置>
	设置URL(服务器地址)： http://XXXXXX.com/index.php/Wechat/index (根据你的网站域名申请！替换XXXXXX.com )
	Token(令牌)： hjk  (更具你的喜好填写！)

###Blog配置
进入后台的：http://XXXXXX.com/index.php/User/wechat (根据你的网站域名申请！替换XXXXXX.com )
填写Token 和验证码 （验证码是你验证你自己的微信号所用）

完成后点击“提交”[此时 下面显示 “失败” ，然后继续下面步骤]

在你微信中公众号中找到你刚刚申请的公众号,发送你的 验证码！[刚刚你在blog配置上 填写的验证码]
完成绑定！

此时 “点击导航栏的"微信绑定"即可在下面显示成功！【请不要刷新刚刚的页面！】”



