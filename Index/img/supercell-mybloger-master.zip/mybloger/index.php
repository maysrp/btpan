<?php
	define('APP_PATH','./Index/');
	define('APP_NAME','Index');
	//define('APP_DEBUG',True);
	require './Core/ThinkPHP.php';


?>